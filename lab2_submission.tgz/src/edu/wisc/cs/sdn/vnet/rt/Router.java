package edu.wisc.cs.sdn.vnet.rt;
import net.floodlightcontroller.packet.IPv4;
import java.nio.ByteBuffer;
import edu.wisc.cs.sdn.vnet.Device;
import edu.wisc.cs.sdn.vnet.DumpFile;
import edu.wisc.cs.sdn.vnet.Iface;

import net.floodlightcontroller.packet.Ethernet;

/**
 * @author Aaron Gember-Jacobson and Anubhavnidhi Abhashkumar
 */
public class Router extends Device
{	
	/** Routing table for the router */
	private RouteTable routeTable;
	
	/** ARP cache for the router */
	private ArpCache arpCache;
	
	/**
	 * Creates a router for a specific host.
	 * @param host hostname for the router
	 */
	public Router(String host, DumpFile logfile)
	{
		super(host,logfile);
		this.routeTable = new RouteTable();
		this.arpCache = new ArpCache();
	}
	
	/**
	 * @return routing table for the router
	 */
	public RouteTable getRouteTable()
	{ return this.routeTable; }
	
	/**
	 * Load a new routing table from a file.
	 * @param routeTableFile the name of the file containing the routing table
	 */
	public void loadRouteTable(String routeTableFile)
	{
		if (!routeTable.load(routeTableFile, this))
		{
			System.err.println("Error setting up routing table from file "
					+ routeTableFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static route table");
		System.out.println("-------------------------------------------------");
		System.out.print(this.routeTable.toString());
		System.out.println("-------------------------------------------------");
	}
	
	/**
	 * Load a new ARP cache from a file.
	 * @param arpCacheFile the name of the file containing the ARP cache
	 */
	public void loadArpCache(String arpCacheFile)
	{
		if (!arpCache.load(arpCacheFile))
		{
			System.err.println("Error setting up ARP cache from file "
					+ arpCacheFile);
			System.exit(1);
		}
		
		System.out.println("Loaded static ARP cache");
		System.out.println("----------------------------------");
		System.out.print(this.arpCache.toString());
		System.out.println("----------------------------------");
	}

	/**
	 * Handle an Ethernet packet received on a specific interface.
	 * @param etherPacket the Ethernet packet that was received
	 * @param inIface the interface on which the packet was received
	 */
	public void handlePacket(Ethernet etherPacket, Iface inIface)
	{
		System.out.println("*** -> Received packet: " +
				etherPacket.toString().replace("\n", "\n\t"));
		
		/********************************************************************/
		/* TODO: Handle packets                                             */
		//drop packet if not ipv4
		if (etherPacket.getEtherType() != Ethernet.TYPE_IPv4) {
			return;
		}
		IPv4 header = (IPv4) etherPacket.getPayload();		
		short checksum = header.getChecksum();
		header.resetChecksum();
		header.serialize();
		short calc_checksum = header.getChecksum();

		//invalid checksum so drop packet
		if (calc_checksum != checksum) {
			return;
		}
		
		//if ttl is less than 0, drop packet
		if (header.getTtl() <= 0) {
			return;
		}
		header.setTtl((byte)(header.getTtl() - 1));
		header.resetChecksum();
		
		//if destination is for router, drop packet
		int dest_addr = header.getDestinationAddress();
		for (Iface router_interface : this.interfaces.values()) {
    			if (dest_addr == router_interface.getIpAddress()) {
        			return;
   			 }
		}

		RouteEntry longest_prefix_route = this.routeTable.lookup(dest_addr);
		//if longest prefix cannot be found, drop packet
		if(longest_prefix_route == null) {
			return;
		}

		int next_ip = longest_prefix_route.getGatewayAddress();
		if(next_ip == 0) {
			next_ip = dest_addr;
		}

		//this is the ethernet destination mac addr
		ArpEntry arp_cache_mac_addr = this.arpCache.lookup(next_ip);
		//if no mac addr found in cache, drop packet
		if (arp_cache_mac_addr == null) {
			return;
		}

		//this be the physical port packet goes out of 
		Iface outgoing_port = this.interfaces.get(longest_prefix_route.getInterface().getName());
		//network addr of the root
		int dest_route = longest_prefix_route.getDestinationAddress();
		//subnet mask 
		int mask_route = longest_prefix_route.getMaskAddress();

		//ethernet source mac aka also router's own mac addr
		ArpEntry router_interface_ip = null;
		for (int i = 1; i <= 10; i++) {
    			int potential_router_ip = (dest_route & mask_route) | i;
    			router_interface_ip = this.arpCache.lookup(potential_router_ip);
    			//we found the actual router ip so we break 
			if (router_interface_ip != null) {
				break;
			}
		}

		//after all that searching, we never found the router ip so we drop
		if (router_interface_ip == null) {
 			return;
		}

		//new source is the router's current interface mac addr
		etherPacket.setSourceMACAddress(router_interface_ip.getMac().toBytes());
		//bew dest is next router hop's mac addr from arp cache
		etherPacket.setDestinationMACAddress(arp_cache_mac_addr.getMac().toBytes());
		this.sendPacket(etherPacket, outgoing_port);
		/********************************************************************/
	}
}
